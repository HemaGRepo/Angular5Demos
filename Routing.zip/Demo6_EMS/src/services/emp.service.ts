import { Injectable,Inject } from '@angular/core';
import { Http,Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Employee } from '../models/Employee';
import 'rxjs/Rx';


@Injectable()
export class GetEmpService{
    private url="http://localhost:4200/api/employee.json"
    
    constructor(@Inject(Http) private http:Http){
        
    }
    
    getAllEmps():Observable<Employee[]>{
        return this.http.get(this.url)
        .map((response:Response)=><Employee[]>response.json())
        .catch(this.handleError);
    }

    getEmpById(eid:number):Observable<Employee[]>{
        return this.http.get(this.url)
        .map(
            (response:Response)=><Employee[]>
            response.json().filter(x=>x.id==eid)
          )
        .catch(this.handleError);
    }
    
    private handleError(error:Response){
        console.log(error);
        return Observable.throw(error.json().error || 'Server Error');
    }
}