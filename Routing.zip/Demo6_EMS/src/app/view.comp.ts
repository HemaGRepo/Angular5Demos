import { Component, Inject } from "@angular/core";
import { Router } from "@angular/router";
import { GetEmpService } from "../services/emp.service";
import { Employee } from "../models/Employee";

@Component({
templateUrl:'../views/employee.display.html',
providers:[GetEmpService]
})
export class DisplayComponent{
      private emps:Employee[];
      private errMsg:String;
    constructor(@Inject(Router) private router:Router,
                @Inject(GetEmpService) private empServ:GetEmpService){

    }

    ngOnInit(){
         this.empServ.getAllEmps().subscribe(
             employees=>this.emps=employees,
             error=>this.errMsg=error
         )
    }
    navigateToHome(){
        this.router.navigate(['/Home'])
    }
}