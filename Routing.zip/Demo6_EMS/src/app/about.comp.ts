import { Component, Inject } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { GetEmpService } from "../services/emp.service";
import { Employee } from "../models/Employee";

@Component({
    templateUrl:'../views/about.html',
    providers:[GetEmpService]
})
export class AboutComponent{
    eid:number;
    e:Employee;
    errMsg:string;
    constructor(@Inject(Router) private router:Router,
                @Inject(ActivatedRoute) private curRoute:ActivatedRoute,
                @Inject(GetEmpService) private empServ:GetEmpService){
       this.eid= parseInt(this.curRoute.snapshot.params['id']);
    }
  
    ngOnInit(){
        this.empServ.getEmpById(this.eid).subscribe(
            employees=>this.e=employees[0],
            error=>this.errMsg=error
        )
    }
    navigateToHome(){
    this.router.navigate(['/Home'])
    }
    navigateToSearch(){
        this.router.navigate(['/Search'])
        }
    navigateToView(){
        this.router.navigate(['/ViewAll'])
    }
}