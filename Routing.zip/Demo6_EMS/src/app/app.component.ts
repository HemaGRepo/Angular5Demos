import { Component } from "@angular/core";

@Component({
selector:"app-root",
templateUrl:'../views/app.main.html'
})
export class AppComponent{

}