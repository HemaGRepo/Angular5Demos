import { Component } from "@angular/core";


@Component({
    templateUrl:'../views/home.html'
})
export class HomeComponent{


}