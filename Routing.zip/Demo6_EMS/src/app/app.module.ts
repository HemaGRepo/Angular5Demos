import { Component, NgModule, enableProdMode, Inject } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule, FormGroup, FormControl, FormBuilder, Validators, FormsModule } from '@angular/forms'
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppComponent } from './app.component';
import {RouterModule, Routes} from '@angular/router';
import { HomeComponent } from './home.comp';
import { AddEmpComponent } from './addemp.comp';
import { SuccessComponent } from './success.comp';
import { DisplayComponent } from './view.comp';
import { HttpModule } from '@angular/http';
import { AboutComponent } from './about.comp';
import { SearchComponent } from './emp.search';

enableProdMode();

const r1:Routes=[
  {path:'Home',component:HomeComponent},
  {path:'AddEmp',component:AddEmpComponent},
  {path:'Success',component:SuccessComponent},
  {path:'ViewAll',component:DisplayComponent},
  {path:'Search',component:SearchComponent},
  {path:'about/:id',component:AboutComponent},
  {path:'',redirectTo:'Home',pathMatch:"full"}
]


@NgModule({
  imports:[ BrowserModule,RouterModule.forRoot(r1,{useHash:false}),FormsModule,HttpModule ],
  declarations:[ AppComponent,HomeComponent,AddEmpComponent,SuccessComponent,AboutComponent,DisplayComponent,SearchComponent],
  bootstrap:[ AppComponent ]
})
export class AppModule{}

platformBrowserDynamic().bootstrapModule(AppModule);