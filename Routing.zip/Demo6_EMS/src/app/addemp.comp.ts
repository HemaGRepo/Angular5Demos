import { Component, Inject } from "@angular/core";
import { Employee } from "../models/Employee";
import { Router } from "@angular/router";

@Component({
    templateUrl:'../views/add.emp.html'
})
export class AddEmpComponent{

    constructor(@Inject(Router) private router:Router){

    }
    onSubmit(emp:Employee,isValid:boolean){
        if(isValid){
            var id=emp.id+"";
            localStorage.setItem("Eid",id);
            localStorage.setItem("Name",emp.name);
            localStorage.setItem("Desig",emp.desig);
            this.router.navigate(['/Success'])
        }
    }

    navigateToHome(){
        this.router.navigate(['/Home'])
    }
}