
import { Component, Inject } from "@angular/core";
import { Router } from "@angular/router";

@Component({
    templateUrl:'../views/emp.search.html'
})
export class SearchComponent{
    constructor(@Inject(Router) private router:Router){
}
onSubmit(eid:number){
  this.router.navigate(['/about',eid]);
}
navigateToHome(){
this.router.navigate(['/Home'])
}
}