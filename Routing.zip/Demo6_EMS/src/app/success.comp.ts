import { Component, Inject } from "@angular/core";
import { Router } from "@angular/router";
import { Employee } from "../models/Employee";

@Component({
    templateUrl:'../views/success.html'
})
export class SuccessComponent{
    eid:number;
    name:string;
    desig:string;
    constructor(@Inject(Router) private router:Router){
        
    }
    
    ngOnInit(){
        this.eid=parseInt(localStorage.getItem("Eid"));
        this.name=localStorage.getItem("Name");
        this.desig=localStorage.getItem("Desig");
    }
    navigateToHome(){
    this.router.navigate(['/Home'])
    }
}