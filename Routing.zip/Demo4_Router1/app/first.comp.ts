import { Component } from "@angular/core";

@Component({
    selector:"app-root",
    template:`<h1> Welcome to First component</h1>
    <h2> Home Sweet Home </h2>`
    })
    export class Comp1{
    
    }