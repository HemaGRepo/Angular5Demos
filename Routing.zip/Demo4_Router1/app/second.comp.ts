import { Component } from "@angular/core";

@Component({
    selector:"app-root",
    template:`<h1> Add Employee </h1>
    <h2> Employee Form </h2>`
    })
    export class Comp2{
    
    }