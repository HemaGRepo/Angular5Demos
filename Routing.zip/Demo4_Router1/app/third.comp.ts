import { Person } from "./person";
import { Component } from "@angular/core";

@Component({
    selector:"app-root",
    template:`<h1> Add Employee </h1>
    <h2> Table </h2>
    <h3>{{p1.personName}} - {{p1.personAge}}</h3>`
    })
    export class Comp3{
    p1:Person={personName:"Sam",personAge:78}
    }