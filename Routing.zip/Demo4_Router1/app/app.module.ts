import { Component, NgModule, enableProdMode, Inject } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule, FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms'
import { Person } from './person'
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppComponent } from './app.component';
import { Comp1 } from './first.comp';
import { Comp2 } from './second.comp';
import { Comp3 } from './third.comp';
import {RouterModule, Routes} from '@angular/router';
enableProdMode();

const r1:Routes=[
  {path:'Home',component:Comp1},
  {path:'AddEmp',component:Comp2},
  {path:'ViewEmp',component:Comp3},
  {path:'',redirectTo:'Home',pathMatch:"full"}
]


@NgModule({
  imports:[ BrowserModule,RouterModule.forRoot(r1,{useHash:false}) ],
  declarations:[ AppComponent,Comp1,Comp2,Comp3 ],
  bootstrap:[ AppComponent ]
})
export class AppModule{}

platformBrowserDynamic().bootstrapModule(AppModule);