import { Component } from "@angular/core";
import { ActivatedRoute } from "@angular/router";

@Component({
    selector:"app-root",
    template:`<h1> Add Employee </h1>
    <h2> Employee Form </h2>
    <h3> The parameter passed is {{idFromRoute}}</h3>`
    })
    export class Comp2{

        idFromRoute:number;

        constructor(a1:ActivatedRoute){
            this.idFromRoute=a1.snapshot.params.empId;

        }
    
    }