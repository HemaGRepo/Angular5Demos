import { Person } from "./person";
import { Component } from "@angular/core";
import { Router } from "@angular/router";

@Component({
    selector:"app-root",
    template:`<h1> Add Employee </h1>
    <h2> Table </h2>
    <h3>{{p1.personName}} - {{p1.personAge}}</h3>
    <button
    class="btn btn-lg btn-primary col-lg-8"
    (click)="display()">Success</button>`
    })
    export class Comp3{
    p1:Person={personName:"Sam",personAge:78}

    constructor(private router:Router){

    }

    display(){
        this.router.navigate(['/Success']);

    }
    }