import { Person } from "./person";
import { Component } from "@angular/core";

@Component({
    selector:"app-root",
    template:`<h1> Successfully Added!!! </h1>
    `
    })
    export class SuccessComp{
    
    }