import { BrowserModule } from '@angular/platform-browser';
import { enableProdMode,NgModule, Component } from '@angular/core';
import {FormsModule} from '@angular/forms'

@Component({
selector:'app-root',
template:`
<div class="container">
<h1 [ngStyle]="{'font-style': style, 'font-size': size, 'font-weight': weight}">
Change style of this text!
</h1>
<hr>
<label><input type="checkbox" (change)="changeStyle($event)">Italic</label>
<label><input type="checkbox" (change)="changeWeight($event)">Bold</label>
<label>Size: <input type="text" [value]="size" (change)="size = $event.target.value"></label>
<hr/>
<h1 [ngStyle]="{'color':c}">The color is changed</h1>
<hr/>
<h1 [ngStyle]="{'color':b}">The color is changed</h1>
<input type="color" [(ngModel)]="b"/>
<hr/>
<input type="button" [ngClass]="{active:isOn}" (click)="Change()" value="Coloured"/>
</div>`,
styles: ['.active { background-color: yellow;}']
})
export class AppComponent{
  style:string = 'normal';
	weight:string = 'normal';
  size:string='20px';
  c:string="red";
  b:string="blue";
  isOn:boolean=true;
	changeStyle($event: any){
		this.style = $event.target.checked ? 'italic' : 'normal';
	}
	changeWeight($event: any) {
     this.weight = $event.target.checked ? 'bold' : 'normal';
   }
   Change(){
     this.isOn=!this.isOn;
   }
}


@NgModule({
  imports:      [ BrowserModule,FormsModule ],
  declarations: [ AppComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }

enableProdMode();

