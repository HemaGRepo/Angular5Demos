import { Pipe, PipeTransform } from '@angular/core';


@Pipe({
 name: 'checkNames',
 pure:false
})
export class NameFilter {
  transform(value: string[], args: string[]): any 
  {
   return value.filter(x=>x.match("e"));
  }
}
