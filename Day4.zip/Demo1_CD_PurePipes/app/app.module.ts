import { Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { enableProdMode } from '@angular/core';
import { NgModule }      from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { InnerComponent } from './inner.component';
import { NameFilter } from './nameFilter';

enableProdMode();

@Component({
  selector: 'app-root',
  template:`<div class="container">
    <inner-app [employeeObj]="employee"></inner-app>
    <hr/>
    <button (click)="changeProperty()">Change Property</button>
    <button (click)="changeObject()">Change Object</button>
 
  <br/>
  {{names|checkNames}}
  </div>`
})

export class MainComponent {
  employee:{id:number,name:string};
  names:String[];

    constructor(){
        this.employee = {id:101,name:'Karthik'};
        this.names=["Mumbai","Pune","Delhi","Hyderabad","Chennai"];
    }

    changeProperty():void{
		console.log("Name Changed to Ganesh");
        this.employee.name = "Ganesh";
        this.names.push("Indore");
        this.names.push("Bangalore");
    }

   changeObject():void{
		console.log("Name Changed to Anil");
        this.employee = {id:101,name:"Anil"};//Immutable Objects
        this.names=["Mumbai","Pune","Delhi","Hyderabad","Chennai","Indore","Bangalore"];
    }
}

@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ MainComponent,InnerComponent,NameFilter ],
  bootstrap:    [ MainComponent ]
})
export class AppModule { }



enableProdMode();
platformBrowserDynamic().bootstrapModule(AppModule);

