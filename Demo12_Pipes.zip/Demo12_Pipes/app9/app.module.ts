import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component, enableProdMode} from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: `./display.html`
})

class PipeComponent{
	name:string ="Karthik";
  today = new Date();
  pi: number = 3.1415927;
  obj: Object = { 
    name: {fName: "Sachin", lName:"Tendulkar"},
    site:"CapgeminiPortal", 
    luckyNumbers:[7,13,69] };
  myNum: number = 0.1415927;
  str: string = "capgemini.com";
	names: string[] = ['Virat', 'Dhoni', 'Dhawan', 'Raina', 'Irfan']
}

@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ PipeComponent ],
  bootstrap:    [ PipeComponent]
})
export class AppModule { }

enableProdMode();

