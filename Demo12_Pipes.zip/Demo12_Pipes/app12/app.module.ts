import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component, enableProdMode} from '@angular/core';
import {Pipe1, ArrayPipe} from './mypipes';

@Component({
  selector:'app-root',
  template:`
   <div class="container">
   <h1> Custom Pipe</h1>
   <h2> {{name|cgPipe:"upper"}}</h2>
   <h2> {{marks|fetchNumbers:"even"}}</h2>
   <h2> {{marks|fetchNumbers:"odd"}}</h2>
   <h2>{{3+4}}</h2>
   <h2 ngNonBindable>{{3+4}}</h2>
   <h2 ngNonBindable> {{marks|fetchNumbers:"odd"}}</h2>
   </div>
  `
})
export class AppComp{
  name:string="Capgemini";
  marks:number[]=[345,89,14,10,89,43,91,76,93,40,23,26]
}

@NgModule({
	imports:[ BrowserModule ],
	declarations:[ AppComp,Pipe1,ArrayPipe ],
	bootstrap:[ AppComp ]
})
export class AppModule{}


enableProdMode();

