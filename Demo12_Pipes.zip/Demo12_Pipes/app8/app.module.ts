import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component, enableProdMode} from '@angular/core';
import {FormsModule} from '@angular/forms'

@Component({
  selector: 'app-root',
  template: `<div class="container">
	<h1>Working with in-built Pipe(Filters)</h1>
  <hr/>
  <h2>{{name}}</h2>
	<h2>{{ name | uppercase }}<h2>
  <h2>{{ today | date : "dd,EEEE MMMM yyyy" | uppercase }}<h2>
    <h2>{{ today | date :"MM-dd-yyyy" }}<h2>
    <h1>{{msg|titlecase}}</h1>
    <h1>{{msg|uppercase}}</h1>
    <h1>{{msg|lowercase}}</h1>
  <div>`
})

class PipeComponent{
	name:string ="Ricky Ponting";
  today = new Date();
  msg:string="The value I pass here is correct let's check"
}

@NgModule({
  imports:      [ BrowserModule,FormsModule ],
  declarations: [ PipeComponent ],
  bootstrap:    [ PipeComponent]
})
export class AppModule { }

enableProdMode();

