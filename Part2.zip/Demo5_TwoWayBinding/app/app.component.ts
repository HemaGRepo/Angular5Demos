import { Component } from '@angular/core';

@Component({
  selector:'app-root',
  templateUrl:'./display.html'
})
export class CgComponent{
  customerName:string;
  choice:string;
  loc:string;

  constructor(){
   this.customerName='Rahul Dravid';
  }

 
}