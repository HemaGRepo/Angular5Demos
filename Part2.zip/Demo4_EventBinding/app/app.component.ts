import { Component } from '@angular/core';

@Component({
  selector:'app-root',
  templateUrl:'./display.html'
})
export class CgComponent{
  prodID:number;
  prodName:string;
  message:string;
  imgUrl:string;
  status:boolean;

  constructor(){
    this.prodID=678;
    this.prodName="Laptop"
    this.imgUrl="assets/hero.jpg"
    this.status=true;
  }

  display(){
    return "Product Details Display ...."+this.prodName;
  }

  changeData(){
      this.prodName="Electronics";
      this.prodID=2222;
  }

  setMsg(){
    this.message="New Message Received"
  }

  toggleImg(){
      this.status=!this.status;
      if(this.status)
        this.imgUrl="assets/hero.jpg"
      else
        this.imgUrl="assets/104.jpg"
  }
}