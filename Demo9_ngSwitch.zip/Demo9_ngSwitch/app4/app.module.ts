import { BrowserModule } from '@angular/platform-browser';
import { enableProdMode,NgModule, Component } from '@angular/core';
import {FormsModule} from '@angular/forms'

@Component({
selector:'app-root',
templateUrl:`./app.component.html`
})
export class AppComponent{
 counter:number=0;
 increment(){
   this.counter+=1;
 }
}


@NgModule({
  imports:      [ BrowserModule,FormsModule ],
  declarations: [ AppComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }

enableProdMode();

