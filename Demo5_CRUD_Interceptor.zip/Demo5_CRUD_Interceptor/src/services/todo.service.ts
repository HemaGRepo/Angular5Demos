import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders, HttpErrorResponse } from "@angular/common/http";
import { URLS } from "../constants/url.const";
import { ToDo } from "../models/todo";
import { Observable } from "rxjs/Observable";
import { filter, map } from 'rxjs/operators';
import { AppErrorHandler } from "../models/AppError";
import { ErrorObservable } from "rxjs/observable/ErrorObservable";
import {catchError} from "rxjs/operators";

@Injectable()
export class TodoService{
    //use the built in Http feature to get the data from backend
    constructor(private http:HttpClient){

    }

    getAllTodos():Observable<ToDo[]|AppErrorHandler>{
      return this.http.get<ToDo[]|AppErrorHandler>(URLS.APIURL)
      .pipe(catchError(err=>this.httpErrorHandler(err)));
    }

    getById(id:number):Observable<ToDo|AppErrorHandler>{
        return this.http.get<ToDo|AppErrorHandler>(URLS.APIURL+"/"+id)
        .pipe(catchError(err=>this.httpErrorHandler(err)));
      }

    addTodo(todo:ToDo):Observable<ToDo|AppErrorHandler>{
        return this.http.post<ToDo|AppErrorHandler>(URLS.APIURL,JSON.stringify(todo),
        {headers:new HttpHeaders({'Content-Type':'application/json'})
      }).pipe(catchError(err=>this.httpErrorHandler(err)));
    }

    updateTodo(todo:ToDo):Observable<ToDo|AppErrorHandler>{
        return this.http.put<ToDo|AppErrorHandler>(URLS.APIURL+"/"+todo.id,JSON.stringify(todo),
        {headers:new HttpHeaders({'Content-Type':'application/json'})
      }).pipe(catchError(err=>this.httpErrorHandler(err)));
   }

    deleteToDo(id:number):Observable<Object|AppErrorHandler>{
        return this.http.delete<Object|AppErrorHandler>(`${URLS.APIURL}/${id}`)
        .pipe(catchError(err=>this.httpErrorHandler(err)));
    }

    httpErrorHandler(err:HttpErrorResponse):Observable<AppErrorHandler>{
        let appErr=new AppErrorHandler();
         appErr.status=err.status;
         appErr.statusText=err.statusText;
         appErr.url=err.url;
         appErr.message=err.message;
         return ErrorObservable.create(appErr);
     }
   
}