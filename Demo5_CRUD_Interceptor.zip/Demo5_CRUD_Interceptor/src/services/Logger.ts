import { HttpInterceptor, HttpHandler, HttpEvent, HttpEventType } from "@angular/common/http";
import { HttpRequest } from "@angular/common/http";
import { Observable } from "rxjs/Observable";
import { tap } from "rxjs/operators";

export class LoggerInterceptor implements HttpInterceptor {
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        console.log("Request URL :"+`${req.url}`)
        console.log("Changing the reuest...");
        let newReq=req.clone();
        return next.handle(newReq).pipe(
            tap(event=>{
                if(event.type==HttpEventType.Response){
                    event.body.title='----------This is a new Title----------';
                    console.log(event.body.title);
                }
            })
        );
    }
}