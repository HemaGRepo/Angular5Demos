export class AppErrorHandler{
    status:number;
    statusText:string;
    url:string;
    message:string;
}