import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component, enableProdMode} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoggerInterceptor } from '../services/Logger';


@NgModule({
	imports:[ BrowserModule,FormsModule,HttpClientModule ],
	declarations:[AppComponent],
  bootstrap:[ AppComponent ],
  providers:[{provide:HTTP_INTERCEPTORS,useClass:LoggerInterceptor,multi:true}]
 
})
export class AppModule{}


enableProdMode();

