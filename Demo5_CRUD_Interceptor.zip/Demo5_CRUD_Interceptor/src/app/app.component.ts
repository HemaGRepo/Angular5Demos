import { Component } from "@angular/core";
import { ToDo } from "../models/todo";
import { TodoService } from "../services/todo.service";
import { AppErrorHandler } from "../models/AppError";

@Component({
    selector:'app-root',
    templateUrl:'todo.display.html',
    providers:[TodoService]
})
export class AppComponent{
   todos:ToDo[]=[];
   err:String;
   id:number;
   message:string;

   constructor(private ts:TodoService){
    this.id=78;
   }

   ngOnInit():void{

   }

   getAll(){
    this.ts.getAllTodos().subscribe(
        (data:ToDo[])=>{this.todos=[]; this.todos=data;
        this.message="Fetched All TodoS successfully"},
        (error:AppErrorHandler)=>{console.log(error)}
    );
   }

   getById(){
    this.ts.getById(this.id).subscribe(
        (data:ToDo)=>{this.todos=[]; this.todos[0]=data;
            this.message="Fetched Todo"+this.id+" successfully"},
            (error:AppErrorHandler)=>{console.log(error)}
    );
   }

   addTodo(){
            let v1:ToDo={ "userId": 555,
            "id": 569,
            "title": "Finish CRUD",
            "completed": false}
            this.ts.addTodo(v1).subscribe(
                (data:ToDo)=>{this.todos=[]; this.todos[0]=data;
                    this.message="Added successfully"},
                    (error:AppErrorHandler)=>{console.log(error)}
            );
  }

   deleteTodo(){
    this.ts.deleteToDo(this.id).subscribe((object:ToDo)=>{
        this.todos=[object];
        this.message="Deleted the Todo with ID:"+object.id;
        }, (error:AppErrorHandler)=>{console.log(error)});
   }

   updateTodo(){
                let v1:ToDo={ "userId": 900,
                "id": 10777,
                "title": "New Updated Value",
                "completed": false}
                this.ts.updateTodo(v1).subscribe(
                    (data:ToDo)=>{this.todos=[]; this.todos[0]=data;
                        this.message="Updated successfully"},
                        (error:AppErrorHandler)=>{console.log(error)}
                );

   }
   
}