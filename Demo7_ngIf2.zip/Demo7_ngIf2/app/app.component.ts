import { BrowserModule } from '@angular/platform-browser';
import { enableProdMode,NgModule, Component } from '@angular/core';
import {FormsModule} from '@angular/forms'

@Component({
selector:'app-root',
template:`
<div class="container">
<h1> Welcome to Angular Directives - If</h1>
<h1 *ngIf='status'>This will be displayed</h1>
<h1 *ngIf='salary<15000' class="text-danger">Less salary!!!</h1>
<h1 *ngIf='salary>15000' class="text-success">More salary!!!</h1>
<hr/>
<input type="button" value="SHOW/HIDE"
class="btn btn-lg btn-warning" (click)=change()/>
<hr/>
<figure *ngIf='show'>
 <img src='assets/102.jpg'/>
</figure>
</div>
<div *ngIf='show; then aboutUs else locationDiv'>

</div>

<ng-template #aboutUs>
    <h1> About Capgemini</h1>
</ng-template>
<ng-template #locationDiv>
     <h1>Locations we operate...</h1>
 </ng-template></section>
`
})
export class CgComponent{
  status:boolean=false;
  salary:number=105290;
  show:boolean=true;

  change(){
    this.show=!this.show;
  }
}

