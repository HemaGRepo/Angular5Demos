import { Component } from '@angular/core';

@Component({
  selector:'app-root',
  templateUrl:'./display.html'
})
export class CgComponent{
  prodID:number;
  prodName:string;
  imgUrl:string;

  constructor(){
    this.prodID=678;
    this.prodName="Laptop"
    this.imgUrl="assets/hero.jpg"
  }

  display(){
    return "Product Details Display ...."+this.prodName;
  }
}