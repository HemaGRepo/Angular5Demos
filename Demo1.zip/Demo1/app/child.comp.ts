import { Component, Input, Output,EventEmitter} from "@angular/core";


@Component({
    selector:"child-comp",
   template:`
   <hr/>
   <h3 class="alert alert-danger text-center">
    Hi... from Child : {{msg}}..{{id}}
   </h3>
   <input type="button" value="Send Data"
   class="btn btn-lg btn-warning"
   (click)="sendMsg()"/>
   <input type="button" value="Send Company"
   class="btn btn-lg btn-secondary"
   (click)="sendComp()"/>
   `
})
export class ChildComponent{
 @Input() msg:string;
 @Input() id:number;

 @Output() toParent:EventEmitter<String>=new EventEmitter<String>();
 @Output() company:EventEmitter<String>=new EventEmitter<String>();

 sendMsg(){
     this.toParent.emit("From Child..to Parent...")
 }

 sendComp(){
    this.company.emit("Capgemini...")
}
  }

