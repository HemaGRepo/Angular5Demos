import { Component } from "@angular/core";
import { Accounts } from "../models/Account.data";

@Component({
    selector:"app-root",
   template:`
   <header class="jumbotron">
   <h1 class="text-center">Welcome to parent Child</h1>
   </header>
   <hr/>
   <h1 class="alert alert-success text-center">
     Hi.... From Parent...<h3 class="text-danger">{{childData}}-{{co}}</h3>
   </h1>
   <child-comp [msg]='message' [id]='code' 
   (toParent)='setData($event)'
   (company)='getComp($event)'></child-comp>
   <hr/>
   <h1 class="alert alert-success text-center">
    Bye.... From Parent
   </h1>
   `
})
export class ParentComponent{
  message:string;
  code:number;
  childData:string;
  co:string;

  constructor(){
      this.message="This is a message from Parent";
      this.code=84978;
  }

  setData(data:string){
      this.childData=data;
  }
  getComp(data:string){
    this.co=data;
  }
  }

