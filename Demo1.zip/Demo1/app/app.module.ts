import { BrowserModule } from '@angular/platform-browser';
import { enableProdMode,NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'


import { ParentComponent } from './app.component';
import { ChildComponent } from './child.comp';


@NgModule({
  imports:      [ BrowserModule,FormsModule ],
  declarations: [  ParentComponent,ChildComponent ],
  bootstrap:    [  ParentComponent ]
})
export class AppModule { }


