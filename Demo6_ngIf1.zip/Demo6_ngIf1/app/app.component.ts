import { Component } from '@angular/core';

@Component({
  selector:'app-root',
  templateUrl:'./display.html'
})
export class CgComponent{
  status:boolean;
  isHome:boolean;
  isServices:boolean;

  constructor(){
   this.status=false;
   this.isHome=false;
   this.isServices=false;
  }
  changeStatus(){
      this.status=!this.status;
  }

  setHome(){
    this.isHome=true;
    this.isServices=false;
  }
 
  setServices(){
    this.isHome=false;
    this.isServices=true;
  }
}