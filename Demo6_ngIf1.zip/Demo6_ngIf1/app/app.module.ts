import { BrowserModule } from '@angular/platform-browser';
import { enableProdMode,NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'


import { CgComponent } from './app.component';


@NgModule({
  imports:      [ BrowserModule,FormsModule ],
  declarations: [  CgComponent],
  bootstrap:    [  CgComponent ]
})
export class AppModule { }


