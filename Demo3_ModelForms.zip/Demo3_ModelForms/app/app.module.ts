import { Component, NgModule, enableProdMode, Inject } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule, FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms'
import { Person } from './person'
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
enableProdMode();

enableProdMode();

@Component({
  selector: 'app-root',
  templateUrl: './model.component.html'
})

export class ModelFormComponent {
  personForm : FormGroup;
  person:Person;
  
  constructor(@Inject(FormBuilder) private builder:FormBuilder){
    this.builtForm();
  }
  private builtForm(){
   let  person1 = new FormControl('Allen', [
      Validators.required,
      Validators.minLength(5),
    ]);
  this.personForm = new FormGroup({
            personName:person1,
            personAge: new FormControl('18')
    });
  }
  
   onSubmitForm(){
    this.person = this.personForm.value;
    let status=this.personForm.valid;
    alert("Status :"+status)
     alert("Name : "+this.person.personName+" Age : "+this.person.personAge);
	}
}

@NgModule({
  imports:[ BrowserModule, ReactiveFormsModule ],
  declarations:[ ModelFormComponent ],
  bootstrap:[ ModelFormComponent ]
})
export class AppModule{}

platformBrowserDynamic().bootstrapModule(AppModule);