import { BrowserModule } from '@angular/platform-browser';
import { enableProdMode,NgModule, Component } from '@angular/core';
import {FormsModule} from '@angular/forms'

@Component({
selector:'app-root',
templateUrl:`./display.html`
})
export class CgComponent{
  empids:number[]=[123,5667,348,900,3567,6729,934,200];
  emps:Employee[]=[  {name:"Shiv",salary:78786,loc:'Chennai'},
                     {name:"Ram",salary:23242,loc:'Pune'},
                     {name:"Sita",salary:54545,loc:'Mumbai'},
                     {name:"Laksh",salary:75664,loc:'Chennai'},
                     {name:"Ravan",salary:83642,loc:'Pune'},
                     {name:"Krish",salary:30000,loc:'Mumbai'}];
  cities:string[]=['Chennai','Mumbai','Pune','Delhi','Bangalore','Noida'];
  selection:string;
  selection2:string;
  sal:string;
}


interface Employee{
   name:string;
   salary:number;
   loc:string;
}
