export class Customer{
    cid:number;
    name:string;
    constructor(){
        console.log("Created a Customer...");
        this.cid=900;
        this.name="Steve";
    }
}