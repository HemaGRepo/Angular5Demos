export class Employee{
    id:number;
    salary:number;
    constructor(){
        console.log("Created an Employee...")
        this.id=100;
        this.salary=18989;
    }
}