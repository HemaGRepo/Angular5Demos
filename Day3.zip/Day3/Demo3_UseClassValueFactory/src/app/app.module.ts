import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component, enableProdMode} from '@angular/core';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { Employee } from '../models/Employee.main';
import {Customer } from '../models/Customer';

export function f1(){
  return function(n1:number,name:string){
       return "Welcome : "+name+" Count  : "+n1;
  }
}

export function f2(){
  return function(){
       return "This is a code from F2";
  }
}

@NgModule({
	imports:[ BrowserModule,FormsModule ],
	declarations:[AppComponent],
  bootstrap:[ AppComponent ]
 
})
export class AppModule{}


enableProdMode();

