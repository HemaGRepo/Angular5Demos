import { Inject, Component } from "@angular/core";
import { Customer } from "../models/Customer";
import { f2 } from "./app.module";

@Component({
    selector: 'app-root',
    template: `<div class="container">
    <h1> Class Provider Example</h1>
    <h1> Value Provider Example...{{t1}}</h1>
    <h1> Copyright &copy; {{c1}}
    <div>`,
    providers:[
        {provide:'Person',useClass:Customer},//Class Provider
        {provide:'TAX_RATE',useValue:11.56}, //Value Provider
        {provide:'display',useFactory:f2},
        {provide:'company',useValue:"Capgemini University"} //Factory Provider
       ]
})
export class AppComponent{
    constructor(@Inject('Person') private p1, 
                @Inject('TAX_RATE') private t1:number,
             //   @Inject('display') private print,
                @Inject('company') private c1)
    {
        console.log(p1.cid+" "+p1.name)
        console.log(t1);
     //  console.log(print());
    }
}