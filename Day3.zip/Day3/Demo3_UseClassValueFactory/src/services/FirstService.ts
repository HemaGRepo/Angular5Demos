import { Injectable } from "@angular/core";
import { IEmployee } from "../models/Employee";

@Injectable()
export class FirstService{
msg:string;
 
getDetails():IEmployee{
    return {id:78,name:"Parul"}
}

getMsg():string{
    return this.msg;
}
}