import { Component } from "@angular/core";
import { EmployeeService } from "../services/EmpService";
import {IEmployee} from "../models/Employee";
import { DService } from "../services/DummyService";

@Component({
    selector: 'app-root',
    template: `<h1> Service Demo</h1>
    <div>
	<ul>
		<li *ngFor="let employee of employees">{{employee.id}} - {{ employee.name }}</li>
    </ul>
    <h1>{{v1}}</h1>
   <div>
   <input type="button" (click)=f1() value="getMessage"/>
   <div *ngIf="show">
    <h1> {{msg}}</h1>
   </div>
   `
            ,
    providers:[EmployeeService,DService]
})
export class HomeComponent{

    employees:IEmployee[];
    msg:String;
    show:boolean=false;
    v1:string;
    constructor(private empServ:EmployeeService, private ds:DService){
    }

    ngOnInit():void{
        this.employees=this.empServ. getEmps();
        this.v1=this.ds.passData();
    }

    f1():void{
        this.show=true;
        this.msg=this.empServ.getMessage();
    }
   
}