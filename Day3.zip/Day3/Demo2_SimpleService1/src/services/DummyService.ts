import { Injectable } from "@angular/core";
import {IEmployee} from "../models/Employee";

@Injectable()
export class DService{

   passData():string{
       return "Second Service"
   }
}