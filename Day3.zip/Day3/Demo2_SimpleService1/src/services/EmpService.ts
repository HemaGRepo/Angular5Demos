import { Injectable } from "@angular/core";
import {IEmployee} from "../models/Employee";

@Injectable()
export class EmployeeService{

    getEmps():IEmployee[]{

        return [
            {id:101,name:"Vinu"},
            {id:976,name:"Sam"},
            {id:566,name:"Suraj"}
        ]

    }

    getMessage():String{
        return "This is a code 067435";
    }

}