import { Component } from "@angular/core";

@Component({
    selector: 'app-root',
    template: `<h1>LifeCycle hooks</h1>
    <h4>OnInit and OnDestroy</h4>
    <button (click)="toggle()">Toggle</button>
    <hr/>
    <on-init *ngIf="display"></on-init>`
})
export class HomeComponent{
    display:boolean=false;
	constructor(){
		this.display = true;
	}
	toggle(){
		this.display = !this.display;		
    }
    ngOnInit():void{
        console.log("Parent Initialised.....")
    }
    ngOnDestroy(): void{
        alert("Destroy called...")
        console.log("Parent Destroyed.....");
      }
}