import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { URLS } from "../constants/url.const";
import { ToDo } from "../models/todo";
import { Observable } from "rxjs/Observable";

@Injectable()
export class TodoService{
    //use the built in Http feature to get the data from backend
    constructor(private http:HttpClient){

    }

    getAllTodos():Observable<ToDo[]>{
      return this.http.get<ToDo[]>(URLS.APIURL);
    }
}