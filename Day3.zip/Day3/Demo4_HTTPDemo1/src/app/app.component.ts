import { Component } from "@angular/core";
import { ToDo } from "../models/todo";
import { TodoService } from "../services/todo.service";

@Component({
    selector:'app-root',
    templateUrl:'todo.display.html',
    providers:[TodoService]
})
export class AppComponent{
   todos:ToDo[];
   err:String;

   constructor(private ts:TodoService){

   }

   ngOnInit():void{

    this.ts.getAllTodos().subscribe(
        (data:ToDo[])=>{this.todos=data},
        (error:String)=>{this.err=error}
    );

   }
   
}