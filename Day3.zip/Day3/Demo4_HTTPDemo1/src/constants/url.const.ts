export const URLS={
    todosURL:"http://localhost:4200/api/todo.json",
    APIURL:"https://jsonplaceholder.typicode.com/todos"
}